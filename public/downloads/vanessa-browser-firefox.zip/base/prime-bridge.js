(() => {
  const api=globalThis.browser||globalThis.chrome;
  const pending=new Set();
  const allowedOrigins=new Set(['http://127.0.0.1:4317','http://127.0.0.1:4319','http://localhost:4317','http://localhost:4319','https://primegestionale.it','https://www.primegestionale.it','https://prime-gestionale-deruvo.fly.dev']);
  function reply(id,result){window.postMessage({type:'prime-vanessa-browser-result',id,result},location.origin);}
  api.runtime.onMessage.addListener(message=>{
    if(message?.type!=='prime-result'||!pending.has(message.id))return;
    pending.delete(message.id);reply(message.id,message.result);
  });
  window.addEventListener('message',event=>{
    if(event.source!==window||!allowedOrigins.has(event.origin))return;
    if(event.data?.type==='prime-vanessa-browser-probe'){window.postMessage({type:'prime-vanessa-browser-ready'},location.origin);return;}
    if(event.data?.type!=='prime-vanessa-browser-request')return;
    const {id,request}=event.data;
    if(typeof id!=='string'||!/^[-a-f0-9]{16,64}$/.test(id)||!request||typeof request!=='object')return;
    if(request.action==='cancel'){
      api.runtime.sendMessage({type:'prime-cancel',id:request.requestId}).catch(()=>{});
      pending.delete(request.requestId);return;
    }
    if(pending.has(id))return;
    pending.add(id);
    api.runtime.sendMessage({type:'prime-start',id,request,origin:event.origin}).then(result=>{
      if(result?.pending)return;
      pending.delete(id);reply(id,result);
    }).catch(()=>{pending.delete(id);reply(id,{performed:false,reason:'Estensione browser assente o non raggiungibile.'});});
  });
})();
