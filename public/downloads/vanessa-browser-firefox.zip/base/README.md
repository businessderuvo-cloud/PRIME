# Vanessa Browser Assist

Estensione locale WebExtensions per Chrome, Edge, Opera e Brave basati su Chromium 121+, e Firefox 121+ desktop. Opera e Brave usano lo stesso pacchetto Chromium; ogni browser mantiene la propria installazione e le proprie autorizzazioni. Dopo l’approvazione dell’istruzione nella pagina PRIME, Vanessa agisce in autonomia sui siti ufficiali del servizio selezionato. Il browser chiede l’accesso host al provider quando occorre. Gli acquisti richiedono conferma separata.

## Azioni

- Aprire i siti ufficiali presenti in PRIME Connect/Email.
- Ispezionare i soli pulsanti, link e campi visibili, senza leggere il contenuto generale della pagina.
- Premere controlli con etichetta esatta seguendo le istruzioni approvate, senza confermare ogni passaggio.
- Compilare campi con valori ordinari ricevuti per il compito; password, codici, API key e segreti si digitano direttamente nella pagina protetta dell’estensione.
- Inviare o cancellare secondo le istruzioni approvate. Gli acquisti richiedono una conferma separata.

I controlli delle pagine provider sono contenuti non attendibili: i comandi derivano dalle istruzioni approvate dall’utente, mai da istruzioni trovate nei siti. Il login e l’autenticazione a più fattori restano sotto il controllo dell’utente.

## Installazione locale

- **Chrome:** apri `chrome://extensions`, attiva la modalità sviluppatore, scegli “Carica estensione non pacchettizzata” e seleziona questa cartella.
- **Edge:** apri `edge://extensions`, attiva la modalità sviluppatore, scegli “Carica non pacchettizzata” e seleziona questa cartella.
- **Brave:** apri `brave://extensions`, attiva la modalità sviluppatore e scegli “Carica non pacchettizzata”. Brave accetta anche le estensioni del Chrome Web Store.
- **Opera:** apri `opera://extensions`, attiva “Developer Mode” e scegli “Load Unpacked Extension”.
- **Firefox:** apri `about:debugging#/runtime/this-firefox`, scegli “Carica componente aggiuntivo temporaneo…” e seleziona `manifest.json` dentro questa cartella. Il caricamento temporaneo viene rimosso quando Firefox si chiude; per un’installazione permanente serve un componente firmato da Mozilla o distribuito dall’organizzazione.

Il browser chiederà di confermare l’installazione. Per ogni servizio il browser può chiedere una volta il permesso per i domini specifici dell’integrazione.

Il manifest include sia il service worker Chromium sia gli script di background richiesti da Firefox. Il target Safari è 16.4 o successivo perché usa `storage.session`. Il file `browser-extension-safari-upload.zip` contiene un manifest adattato e tutte le risorse dell’estensione. In App Store Connect va caricato in **Xcode Cloud → Safari Web Extension Packager**. Apple richiede un account Apple Developer e un record app; il pacchetto restituito si prova con TestFlight o su un Mac. L’archivio è preparato ma non ancora caricato, firmato o verificato in Safari.

## Limiti operativi

Solo i provider enumerati in `providers.js` e le origini PRIME dichiarate nel manifest sono accettati. Le schede nuove ereditano il provider dalla scheda ufficiale che le apre; un reindirizzamento fuori dai domini approvati interrompe il controllo. I siti possono cambiare i nomi e la struttura dei controlli: se l’etichetta non corrisponde a un solo elemento visibile, l’estensione si ferma.
