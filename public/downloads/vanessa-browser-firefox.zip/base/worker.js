if(typeof importScripts==='function')importScripts('providers.js');
const api=globalThis.browser||globalThis.chrome;
const primeOrigins=new Set(['http://127.0.0.1:4317','http://127.0.0.1:4319','http://localhost:4317','http://localhost:4319','https://primegestionale.it','https://www.primegestionale.it','https://prime-gestionale-deruvo.fly.dev']);
const purchasePattern=/\b(buy|purchase|checkout|place order|confirm order|complete purchase|subscribe|abbonati|sottoscrivi|acquist[oaie]|compra|effettua l’ordine|effettua l'ordine|conferma ordine|concludi acquisto|upgrade plan|attiva piano)\b/i;
const storageKey=id=>'prime-request:'+id,tabKey=target=>'prime-tab:'+target,tabsKey=target=>'prime-tabs:'+target,openingKey=target=>'prime-opening:'+target,taskKey=tabId=>'prime-task:'+tabId;
const normal=value=>String(value||'').replace(/\s+/g,' ').trim().toLocaleLowerCase();
function failure(reason){return {performed:false,reason};}
function validate(request){
  if(!request||!Object.hasOwn(PRIME_PROVIDER_TARGETS,request.target))throw Error('Provider non autorizzato.');
  if(typeof request.task_instructions!=='string'||!request.task_instructions.trim()||request.task_instructions.length>1200)throw Error('Istruzioni del compito mancanti o troppo lunghe.');
  if(request.action==='open_service')return request;
  if(request.action==='open_page'){
    let url;try{url=new URL(request.url);}catch{throw Error('Pagina PRIME non valida.');}
    if(!primeOrigins.has(url.origin)||url.pathname!=='/integration-setup.html'||url.searchParams.get('provider')!==request.target)throw Error('È possibile aprire solo la guida PRIME del servizio scelto.');
    return request;
  }
  if(!['inspect','click','fill_field','submit_form'].includes(request.action))throw Error('Azione browser non supportata.');
  const label=request.action==='fill_field'?request.field_label:request.element_label;
  if(request.action!=='inspect'&&(typeof label!=='string'||!label.trim()||label.length>120))throw Error('Etichetta del campo o pulsante non valida.');
  if(request.action==='fill_field'&&request.value!==undefined&&(typeof request.value!=='string'||request.value.length>4000))throw Error('Valore del campo non valido o troppo lungo.');
  if(request.action!=='fill_field'&&(Object.hasOwn(request,'value')||Object.hasOwn(request,'text')||Object.hasOwn(request,'password')))throw Error('Valore non valido per questa azione.');
  return request;
}
async function rememberTab(target,tabId){
  const data=await api.storage.session.get(tabsKey(target)),ids=Array.isArray(data[tabsKey(target)])?data[tabsKey(target)]:[];
  await api.storage.session.set({[tabsKey(target)]:[...ids.filter(id=>id!==tabId),tabId],[tabKey(target)]:tabId});
}
async function currentTab(target){
  const key=tabKey(target),data=await api.storage.session.get(key);let id=data[key];
  if(id!==undefined&&await api.tabs.get(id).catch(()=>null))return id;
  const list=await api.storage.session.get(tabsKey(target)),ids=Array.isArray(list[tabsKey(target)])?list[tabsKey(target)]:[];
  for(const candidate of ids.slice().reverse())if(await api.tabs.get(candidate).catch(()=>null)){await api.storage.session.set({[key]:candidate});return candidate;}
  return null;
}
api.tabs.onCreated.addListener(tab=>{
  void (async()=>{const data=await api.storage.session.get(null);for(const target of Object.keys(PRIME_PROVIDER_TARGETS)){const ids=data[tabsKey(target)]||[],opening=data[openingKey(target)],isChild=tab.openerTabId!==undefined&&(data[tabKey(target)]===tab.openerTabId||ids.includes(tab.openerTabId)),openedByVanessa=opening&&Date.now()-opening.createdAt<6000&&(tab.openerTabId===undefined||tab.openerTabId===opening.parentTabId);if(isChild||openedByVanessa){await rememberTab(target,tab.id);break;}}})();
});
api.tabs.onUpdated.addListener((tabId,changeInfo)=>{
  if(!changeInfo.url)return;
  void (async()=>{const data=await api.storage.session.get(null);for(const target of Object.keys(PRIME_PROVIDER_TARGETS)){const ids=data[tabsKey(target)]||[];if(ids.includes(tabId)&&PRIME_PROVIDER_TARGETS[target].origins.some(pattern=>{try{return new URL(pattern.replace('/*','/')).origin===new URL(changeInfo.url).origin;}catch{return false;}})){await api.storage.session.set({[tabKey(target)]:tabId});break;}}})();
});
async function sendResult(p,result){try{await api.tabs.sendMessage(p.primeTabId,{type:'prime-result',id:p.id,result});}catch{}}
async function originPermission(p){return api.permissions.contains({origins:PRIME_PROVIDER_TARGETS[p.target].origins});}
async function createApproval(p){
  await api.storage.session.set({[storageKey(p.id)]:p});
  const tab=await api.tabs.create({url:api.runtime.getURL('approval.html')+'?id='+encodeURIComponent(p.id),active:true});
  await api.storage.session.set({[storageKey(p.id)]:{...p,approvalTabId:tab.id}});
}
async function runPageAction(p,value='',{dryRun=false,purchaseApproved=false,manualValueApproved=false}={}){
  let originInfo,origin,allowed=false;const deadline=Date.now()+15000;
  do{originInfo=await api.tabs.get(p.providerTabId).catch(()=>null);try{origin=new URL(originInfo?.url||'').origin;}catch{origin='';}allowed=PRIME_PROVIDER_TARGETS[p.target].origins.some(pattern=>new URL(pattern.replace('/*','/')).origin===origin);if(allowed)break;if(!originInfo||Date.now()>=deadline)break;await new Promise(resolve=>setTimeout(resolve,250));}while(Date.now()<deadline);
  if(!originInfo)throw Error('La scheda provider non è disponibile. Riapri il sito ufficiale.');
  if(!allowed)throw Error('La scheda è fuori dai domini ufficiali autorizzati per questo servizio.');
  if(!dryRun&&['click','submit_form'].includes(p.request.action)){const marker={createdAt:Date.now(),parentTabId:p.providerTabId};await api.storage.session.set({[openingKey(p.target)]:marker});setTimeout(async()=>{const data=await api.storage.session.get(openingKey(p.target));if(data[openingKey(p.target)]?.createdAt===marker.createdAt)await api.storage.session.remove(openingKey(p.target));},7000);}
  let result;try{result=await api.scripting.executeScript({target:{tabId:p.providerTabId},func:pageAction,args:[p.request.action,p.request.element_label||p.request.field_label||'',value,purchaseApproved,dryRun,manualValueApproved]});}catch(error){if(p.request.action==='fill_field')throw Error('Il browser non ha compilato il campo. Il valore non è stato conservato.');throw error;}
  return result?.[0]?.result||failure('Il browser non ha restituito un esito.');
}
function pageAction(action,label,value,purchaseApproved,dryRun,manualValueApproved){
  const purchasePattern=/\b(buy|purchase|checkout|place order|confirm order|complete purchase|subscribe|abbonati|sottoscrivi|acquist[oaie]|compra|effettua l’ordine|effettua l'ordine|conferma ordine|concludi acquisto|upgrade plan|attiva piano)\b/i;
  const visible=el=>!!(el&&el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none');
  const tidy=value=>String(value||'').replace(/\s+/g,' ').trim();
  const accessible=el=>tidy(el.getAttribute('aria-label')||el.innerText||el.textContent||el.value);
  if(action==='inspect'){
    const buttons=[...document.querySelectorAll('button,[role="button"],a[href]')].filter(visible).map(accessible).filter(Boolean).slice(0,40);
    const fields=[...document.querySelectorAll('input:not([type="hidden"]),textarea,select')].filter(visible).map(el=>({label:tidy(el.labels?.[0]?.innerText||el.getAttribute('aria-label')||el.placeholder||el.name),type:el.type||el.tagName.toLowerCase()})).filter(x=>x.label).slice(0,40);
    return {performed:true,buttons,fields,pageTitle:document.title.slice(0,120)};
  }
  const wanted=String(label||'').trim().toLocaleLowerCase();
  if(action==='click'||action==='submit_form'){
    const matches=[...document.querySelectorAll('button,[role="button"],a[href],input[type="submit"]')].filter(visible).filter(el=>accessible(el).toLocaleLowerCase()===wanted);
    if(matches.length!==1)return {performed:false,reason:matches.length?'Etichetta ambigua: nessuna azione eseguita.':'Pulsante visibile non trovato.'};
    const el=matches[0];if(action==='submit_form'&&el.tagName==='A')return {performed:false,reason:'La destinazione è un collegamento, non un pulsante di invio.'};
    const form=el.closest('form'),riskText=[accessible(el),el.title,el.getAttribute('aria-label'),el.getAttribute('data-testid'),el.getAttribute('name'),el.href,form?.action,form?.getAttribute('data-testid'),location.pathname,document.title].filter(Boolean).join(' ');
    if(purchasePattern.test(riskText)&&!purchaseApproved)return {performed:false,requiresPurchaseConfirmation:true,reason:'Conferma necessaria prima di completare un acquisto.'};
    if(dryRun)return {performed:false,ready:true};
    el.click();return {performed:true,action,label:accessible(el)};
  }
  if(action==='fill_field'){
    const fields=[...document.querySelectorAll('input:not([type="hidden"]),textarea')].filter(visible).filter(el=>tidy(el.labels?.[0]?.innerText||el.getAttribute('aria-label')||el.placeholder||el.name).toLocaleLowerCase()===wanted);
    if(fields.length!==1)return {performed:false,reason:fields.length?'Etichetta campo ambigua: nessun valore inserito.':'Campo visibile non trovato.'};
    const field=fields[0],fieldLabel=tidy(field.labels?.[0]?.innerText||field.getAttribute('aria-label')||field.placeholder||field.name),sensitive=field.type==='password'||/password|passcode|codice|token|secret|chiave|api key|otp|one.?time|2fa|verifica|security|credential/i.test(fieldLabel+' '+field.autocomplete);
    if(sensitive&&!manualValueApproved)return {performed:false,requiresManualValue:true,reason:'Inserisci il dato di accesso nella finestra protetta dell’estensione.'};
    if(typeof value!=='string'||!value)return {performed:false,requiresManualValue:true,reason:'Inserisci il valore del campo nella finestra protetta dell’estensione.'};
    if(dryRun)return {performed:false,ready:true};
    const setter=Object.getOwnPropertyDescriptor(field instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value')?.set;if(!setter)return {performed:false,reason:'Campo non supportato.'};
    setter.call(field,value);field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));return {performed:true,field:fieldLabel};
  }
  return {performed:false,reason:'Azione sconosciuta.'};
}
async function start(request,sender,id,origin){
  try{
    if(!sender.url||!primeOrigins.has(new URL(sender.url).origin)||!sender.tab?.id||!primeOrigins.has(origin))throw Error('Richiesta non proveniente dal workspace PRIME consentito.');
    if(request?.action==='revoke_task'){
      await api.storage.session.remove(taskKey(sender.tab.id));
      const entries=await api.storage.session.get(null);
      for(const [key,p] of Object.entries(entries))if(key.startsWith('prime-request:')&&p?.primeTabId===sender.tab.id){await api.storage.session.remove(key);await sendResult(p,failure('Autorizzazione revocata con STOP.'));if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});}
      return {performed:true,reason:'Autorizzazione del compito revocata.'};
    }
    validate(request);
    const normalizedInstructions=request.task_instructions.trim(),taskData=await api.storage.session.get(taskKey(sender.tab.id)),taskGrant=taskData[taskKey(sender.tab.id)],taskApproved=!!taskGrant&&taskGrant.expiresAt>Date.now()&&taskGrant.instructions===normalizedInstructions;
    const p={id,request:{...request,task_instructions:normalizedInstructions},origin,target:request.target,primeTabId:sender.tab.id,createdAt:Date.now()};
    if(!taskApproved){p.requiresTaskApproval=true;await createApproval(p);return {pending:true,reason:'Approva le istruzioni del compito nella finestra protetta di Vanessa.'};}
    if(request.action==='open_service'){
      const tab=await api.tabs.create({url:PRIME_PROVIDER_TARGETS[request.target].url,active:true});await rememberTab(request.target,tab.id);
      return {performed:true,reason:'Nuova scheda del servizio ufficiale aperta.',provider:request.target};
    }
    if(request.action==='open_page'){
      const tab=await api.tabs.create({url:request.url,active:true});return {performed:true,reason:'Guida PRIME aperta in una nuova scheda.',tabId:tab.id};
    }
    const providerTabId=await currentTab(request.target);if(!providerTabId)throw Error('Apri prima il sito ufficiale di questo provider tramite Vanessa.');
    p.providerTabId=providerTabId;
    if(!(await originPermission(p))){await createApproval(p);return {pending:true,reason:'Concedi al browser il permesso per il sito ufficiale del servizio.'};}
    const initialValue=typeof request.value==='string'?request.value:'';
    const preview=await runPageAction(p,initialValue,{dryRun:true});
    if(preview.requiresPurchaseConfirmation||preview.requiresManualValue){p.requiresPurchaseConfirmation=!!preview.requiresPurchaseConfirmation;p.requiresManualValue=!!preview.requiresManualValue;await createApproval(p);return {pending:true,reason:preview.reason};}
    const result=preview.ready?await runPageAction(p,initialValue):preview;
    await sendResult(p,result);return {pending:true};
  }catch(error){return failure(error.message||'Azione non eseguita.');}
}
api.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(message?.type==='prime-start'){
    start(message.request,sender,message.id,message.origin).then(sendResponse);return true;
  }
  if(message?.type==='prime-pending'&&sender.url?.startsWith(api.runtime.getURL(''))){
    api.storage.session.get(storageKey(message.id)).then(data=>sendResponse(data[storageKey(message.id)]||null));return true;
  }
  if(message?.type==='prime-cancel'&&sender.url?.startsWith(api.runtime.getURL(''))){
    api.storage.session.get(storageKey(message.id)).then(async data=>{const p=data[storageKey(message.id)];if(p){await api.storage.session.remove(storageKey(message.id));await sendResult(p,failure('Richiesta annullata con STOP.'));if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});}sendResponse({ok:true});});return true;
  }
  if(message?.type==='prime-run-approved'&&sender.url?.startsWith(api.runtime.getURL(''))){
    (async()=>{
      const data=await api.storage.session.get(storageKey(message.id)),p=data[storageKey(message.id)];if(!p)throw Error('Richiesta scaduta.');
      if(Date.now()-p.createdAt>15*60*1000)throw Error('Sessione scaduta.');
      if(p.requiresTaskApproval){if(message.taskApproved!==true)throw Error('Le istruzioni del compito non sono state approvate.');await api.storage.session.set({[taskKey(p.primeTabId)]:{instructions:p.request.task_instructions,expiresAt:Date.now()+60*60*1000}});p.requiresTaskApproval=false;await api.storage.session.set({[storageKey(p.id)]:p});}
      if(['open_service','open_page'].includes(p.request.action)){
        const tab=p.request.action==='open_service'?await api.tabs.create({url:PRIME_PROVIDER_TARGETS[p.target].url,active:true}):await api.tabs.create({url:p.request.url,active:true});
        if(p.request.action==='open_service')await rememberTab(p.target,tab.id);
        await api.storage.session.remove(storageKey(p.id));await sendResult(p,{performed:true,reason:p.request.action==='open_service'?'Nuova scheda del servizio ufficiale aperta.':'Guida PRIME aperta in una nuova scheda.'});
        if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});
        sendResponse({ok:true,reason:'Compito approvato e avviato.'});return;
      }
      if(!(await originPermission(p)))throw Error('Accesso al solo sito non autorizzato.');
      const manualValue=typeof message.value==='string'?message.value:'';
      const manualValueApproved=!!p.requiresManualValue&&manualValue.length>0;
      const preview=await runPageAction(p,manualValueApproved?manualValue:(p.request.value||''),{dryRun:true,purchaseApproved:!!message.purchaseApproved,manualValueApproved});
      if(preview.requiresPurchaseConfirmation){p.requiresPurchaseConfirmation=true;await api.storage.session.set({[storageKey(p.id)]:p});sendResponse({ok:false,requiresPurchaseConfirmation:true,reason:preview.reason});return;}
      if(preview.requiresManualValue){p.requiresManualValue=true;await api.storage.session.set({[storageKey(p.id)]:p});sendResponse({ok:false,requiresManualValue:true,reason:preview.reason});return;}
      const value=manualValueApproved?manualValue:(p.request.value||'');
      const result=preview.ready?await runPageAction(p,value,{purchaseApproved:!!message.purchaseApproved,manualValueApproved}):preview;
      if(result.requiresPurchaseConfirmation||result.requiresManualValue){sendResponse({ok:false,...result});return;}
      await api.storage.session.remove(storageKey(p.id));await sendResult(p,result);
      if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});
      sendResponse({ok:!!result.performed,reason:result.reason||result.action||result.field||''});
    })().catch(async error=>{const data=await api.storage.session.get(storageKey(message.id)),p=data[storageKey(message.id)];if(p){await api.storage.session.remove(storageKey(message.id));await sendResult(p,failure(error.message));}sendResponse({ok:false,reason:error.message});});return true;
  }
});
