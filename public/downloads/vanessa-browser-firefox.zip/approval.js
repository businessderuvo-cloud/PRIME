const api=globalThis.browser||globalThis.chrome,params=new URL(location.href).searchParams,id=params.get('id');
const summary=document.querySelector('#summary'),domain=document.querySelector('#domain'),taskInstructions=document.querySelector('#task-instructions'),form=document.querySelector('#fill'),value=document.querySelector('#value'),permission=document.querySelector('#permission'),purchase=document.querySelector('#purchase'),status=document.querySelector('#status'),approve=document.querySelector('#approve');
let pending=null,hasPermission=false,busy=false,permissionOrigins=[];
const labelFor=request=>request.action==='search_history'?'Consulta la cronologia del browser':request.action==='read_page_text'?'Leggi il testo visibile della pagina':request.action==='fullscreen_window'?'Metti il browser a schermo intero':request.action==='restore_window'?'Ripristina la finestra del browser':request.action==='inspect'?'Leggi le etichette visibili dei controlli':request.action==='click'?'Premi il pulsante/link «'+request.element_label+'»':request.action==='submit_form'?'Invia il modulo con «'+request.element_label+'»':request.action==='fill_field'?'Compila il campo «'+request.field_label+'»':request.action==='open_service'?'Apri il sito ufficiale del servizio':request.action==='open_page'?'Apri la guida di configurazione PRIME':request.action==='stop_video'?'Metti in pausa il video':request.action==='play_video'?'Riprendi il video':request.action==='close_tab'?'Chiudi la scheda attiva':'Azione browser';
function update(){
 if(!pending)return;
 form.hidden=!pending.requiresManualValue;
 purchase.hidden=!pending.requiresPurchaseConfirmation;
 taskInstructions.hidden=!pending.requiresTaskApproval;
 if(pending.requiresTaskApproval)taskInstructions.querySelector('p').textContent=pending.request.task_instructions;
 approve.textContent=pending.requiresPurchaseConfirmation?'Conferma acquisto':!hasPermission?(pending.requiresTaskApproval?'Approva il compito e concedi accesso':'Concedi accesso al sito'):pending.requiresTaskApproval?'Approva il compito e avvia':pending.requiresManualValue?'Inserisci il dato e continua':'Esegui l’istruzione';
}
async function init(){
 if(!id){status.textContent='Richiesta non valida.';return;}
 pending=await api.runtime.sendMessage({type:'prime-pending',id});
 if(!pending){status.textContent='Richiesta scaduta o annullata.';return;}
 const provider=globalThis.PRIME_PROVIDER_TARGETS?.[pending.target];
 if(!provider){status.textContent='Provider non autorizzato.';return;}
 const tab=pending.providerTabId?await api.tabs.get(pending.providerTabId).catch(()=>null):null;
 let host='';try{host=new URL(tab?.url||(pending.request.action==='open_page'?pending.request.url:provider.url)).origin;}catch{}permissionOrigins=pending.permissionOrigins||[pending.permissionOrigin].filter(Boolean);
 const permissionHosts=permissionOrigins.map(origin=>{try{return new URL(origin.replace('/*','')).hostname}catch{return origin}});
 summary.textContent=labelFor(pending.request);
 domain.textContent='Sito ufficiale: '+host;
 const needsHostPermission=!['open_service','open_page'].includes(pending.request.action);
 hasPermission=!needsHostPermission||await api.permissions.contains({origins:permissionOrigins});
 permission.textContent='Il browser chiede accesso ai siti necessari per il compito; la scelta resta gestibile dalle impostazioni dell’estensione.';
 permission.hidden=hasPermission;
 approve.disabled=false;update();
 status.textContent=!needsHostPermission?'Questa operazione apre una nuova scheda PRIME o il sito ufficiale.':hasPermission?'Vanessa ha già il permesso per questo servizio.':'Concedi una volta l’accesso richiesto per questa pagina.';
}
approve.addEventListener('click',async()=>{
 if(!pending||busy)return;
 busy=true;approve.disabled=true;
 try{
   const provider=globalThis.PRIME_PROVIDER_TARGETS[pending.target];
   const needsHostPermission=!['open_service','open_page'].includes(pending.request.action);
   hasPermission=!needsHostPermission||await api.permissions.contains({origins:permissionOrigins});
   if(!hasPermission){const allowed=await api.permissions.request({origins:permissionOrigins});if(!allowed)throw Error('Accesso al sito rifiutato.');hasPermission=true;permission.hidden=true;}
   if(pending.requiresManualValue&&!value.value)throw Error('Inserisci il dato richiesto nel campo protetto.');
   status.textContent=pending.requiresPurchaseConfirmation?'Verifico il permesso per l’acquisto…':'Eseguo l’istruzione approvata…';
   const result=await api.runtime.sendMessage({type:'prime-run-approved',id,value:pending.requiresManualValue?value.value:'',purchaseApproved:!!pending.requiresPurchaseConfirmation,taskApproved:!!pending.requiresTaskApproval});
   pending.requiresTaskApproval=false;
   if(result?.requiresPurchaseConfirmation){pending.requiresPurchaseConfirmation=true;status.textContent='Controlla il sito e il pulsante. Vanessa non ha ancora completato l’acquisto.';update();return;}
   if(result?.requiresManualValue){pending.requiresManualValue=true;status.textContent='Inserisci il dato richiesto nella finestra protetta. Il valore non viene condiviso con Vanessa.';update();return;}
   if(result?.ok){value.value='';status.textContent='Istruzione completata. Il valore inserito non è stato conservato.';pending=null;setTimeout(()=>window.close(),800);return;}
   throw Error(result?.reason||'Azione non eseguita.');
 }catch(error){status.textContent=error.message||'Azione annullata.';}
 finally{busy=false;approve.disabled=!pending;update();}
});
document.querySelector('#cancel').addEventListener('click',async()=>{value.value='';if(id)await api.runtime.sendMessage({type:'prime-cancel',id}).catch(()=>{});window.close();});
void init();
