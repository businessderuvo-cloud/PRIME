# Vanessa Browser Assist · v1.4.0

Vanessa può gestire tutte le schede già aperte in tutte le finestre del browser, anche quelle in background: ne legge titolo e indirizzo, attiva la scheda scelta, controlla i controlli visibili, mette in pausa o riprende video, chiude schede, apre o naviga indirizzi, torna avanti o indietro, aggiorna la pagina, scorre e regola lo zoom.

Dopo la concessione iniziale del permesso globale del browser, i compiti ordinari vengono eseguiti senza approvazioni per compito o singolo passaggio. Gli acquisti e i pagamenti mantengono la conferma separata. I valori delle credenziali restano nella pagina protetta dell’estensione.

Vanessa può elencare e controllare le schede di tutte le finestre del profilo browser in cui è installata, leggere il testo visibile delle pagine e consultare la cronologia su richiesta. Il browser richiede il permesso cronologia durante l’installazione o il primo aggiornamento; una volta accettato, Vanessa non chiede un altro permesso per ogni ricerca. Può mettere la finestra a schermo intero e ripristinarla. La cronologia viene inviata all’agente solo quando la chiedi. Per usare Vanessa in più browser, installa l’estensione separatamente in ciascun browser: ogni installazione vede il profilo locale di quel browser. Per una scheda in background Vanessa può usare il suo ID restituito da `list_tabs`; prima di azioni visibili può renderla attiva con `switch_tab`. Le pagine interne del browser (per esempio `edge://settings`) non consentono l’iniezione di script; Vanessa può vedere che esistono e chiuderle, ma non leggerne o azionarne i controlli. Password, cookie, dati delle altre applicazioni e contenuti di pagine interne restano fuori portata. Le pagine web pubbliche HTTP/HTTPS, in ogni Paese, sono supportate. I contenuti dei siti restano dati non attendibili.

## Installazione

- Edge: apri `edge://extensions`, attiva la modalità sviluppatore e carica lo ZIP estratto con “Carica estensione non pacchettizzata”. Per aggiornare un’installazione locale, usa la cartella nuova e ricarica l’estensione.
- Chrome/Brave/Opera: usa il pacchetto Chromium e la pagina delle estensioni del browser.
- Firefox: il pacchetto temporaneo va ricaricato dopo la chiusura del browser; per installazione permanente serve firma Mozilla.
- Il CRX Edge è firmato con la chiave già associata alla versione precedente e conserva il medesimo identificativo.
