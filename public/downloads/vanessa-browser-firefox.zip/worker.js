if(typeof importScripts==='function')importScripts('providers.js');
const api=globalThis.browser||globalThis.chrome;
const primeOrigins=new Set(['http://127.0.0.1:4317','http://127.0.0.1:4319','http://localhost:4317','http://localhost:4319','https://primegestionale.it','https://www.primegestionale.it','https://prime-gestionale-deruvo.fly.dev']);
const purchasePattern=/\b(buy|purchase|checkout|place order|confirm order|complete purchase|subscribe|abbonati|sottoscrivi|acquist[oaie]|compra|effettua l’ordine|effettua l'ordine|conferma ordine|concludi acquisto|upgrade plan|attiva piano)\b/i;
const storageKey=id=>'prime-request:'+id,tabKey=target=>'prime-tab:'+target,tabsKey=target=>'prime-tabs:'+target,openingKey=target=>'prime-opening:'+target,taskKey=tabId=>'prime-task:'+tabId;
const normal=value=>String(value||'').replace(/\s+/g,' ').trim().toLocaleLowerCase();
function failure(reason){return {performed:false,reason};}
function navigationUrl(value){
  if(typeof value!=='string'||value.length>3000)throw Error('Indirizzo non valido.');
  let url;try{url=new URL(value);}catch{throw Error('Indirizzo non valido.');}
  if(['http:','https:'].includes(url.protocol)&&!url.username&&!url.password)return url.href;
  if(['chrome:','edge:','brave:','opera:'].includes(url.protocol)&&['settings','history','downloads','extensions','bookmarks'].includes(url.hostname)&&!url.username&&!url.password&&!url.port)return url.href;
  if(url.protocol==='about:'&&['preferences','addons','downloads'].includes(url.pathname))return url.href;
  throw Error('Indirizzo non supportato: usa una pagina web o impostazioni, cronologia, download, estensioni e preferiti del browser.');
}
function validate(request){
  if(!request||!Object.hasOwn(PRIME_PROVIDER_TARGETS,request.target))throw Error('Provider non autorizzato.');
  if(typeof request.task_instructions!=='string'||!request.task_instructions.trim()||request.task_instructions.length>1200)throw Error('Istruzioni del compito mancanti o troppo lunghe.');
  if(request.target==='web'&&request.action==='open_service'){const u=new URL(request.url);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('URL non valido.');}if(request.action==='open_service')return request;
  if(request.target!=='web'&&Object.hasOwn(request,'tab_id'))throw Error('La scheda specificata non è valida per questo servizio.');
  if(request.tab_id!==undefined&&(!Number.isSafeInteger(request.tab_id)||request.tab_id<0))throw Error('ID scheda non valido.');
  if(request.frame_id!==undefined&&(!Number.isSafeInteger(request.frame_id)||request.frame_id<0))throw Error('ID frame non valido.');
  if(request.target==='web'&&['list_tabs','switch_tab','close_tab','open_tab','navigate_tab','go_back','go_forward','reload_tab','zoom_tab','duplicate_tab','pin_tab','unpin_tab','mute_tab','unmute_tab','scroll_page','fullscreen_window','restore_window'].includes(request.action)){
    if(request.action==='switch_tab'&&request.tab_id===undefined)throw Error('Specifica l’ID della scheda da attivare.');
    if(['open_tab','navigate_tab'].includes(request.action))navigationUrl(request.url);
    if(request.action==='scroll_page'&&(!['up','down','top','bottom'].includes(request.direction)||request.amount!==undefined&&(!Number.isInteger(request.amount)||request.amount<100||request.amount>3000)))throw Error('Direzione o distanza di scorrimento non valida.');
    if(request.action==='zoom_tab'&&(!Number.isInteger(request.zoom_percent)||request.zoom_percent<50||request.zoom_percent>200))throw Error('Lo zoom deve essere compreso tra 50 e 200 per cento.');
    return request;
  }
  if(request.action==='search_history'){if(request.target!=='web')throw Error('La cronologia è disponibile nel browser, non nei servizi esterni.');if(request.text!==undefined&&(typeof request.text!=='string'||request.text.length>200))throw Error('Testo di ricerca troppo lungo.');for(const key of ['start_time','end_time'])if(request[key]!==undefined&&(!Number.isFinite(request[key])||request[key]<0))throw Error('Intervallo cronologia non valido.');if(request.start_time!==undefined&&request.end_time!==undefined&&request.start_time>request.end_time)throw Error('L’inizio deve precedere la fine.');if(request.max_results!==undefined&&(!Number.isInteger(request.max_results)||request.max_results<1||request.max_results>500))throw Error('Richiedi da 1 a 500 risultati per volta.');return request;}
  if(request.action==='close_tab'||request.action==='stop_video'||request.action==='play_video')return request;
  if(request.action==='open_page'){
    let url;try{url=new URL(request.url);}catch{throw Error('Pagina PRIME non valida.');}
    if(!primeOrigins.has(url.origin)||url.pathname!=='/integration-setup.html'||url.searchParams.get('provider')!==request.target)throw Error('È possibile aprire solo la guida PRIME del servizio scelto.');
    return request;
  }
  if(!['inspect','read_page_text','click','fill_field','submit_form'].includes(request.action))throw Error('Azione browser non supportata.');
  const label=request.action==='fill_field'?request.field_label:request.element_label;
  if(!['inspect','read_page_text'].includes(request.action)&&(typeof label!=='string'||!label.trim()||label.length>4000))throw Error('Etichetta del campo o pulsante non valida.');
  if(request.action==='fill_field'&&request.value!==undefined&&(typeof request.value!=='string'||request.value.length>4000))throw Error('Valore del campo non valido o troppo lungo.');
  if(request.action!=='fill_field'&&(Object.hasOwn(request,'value')||Object.hasOwn(request,'text')||Object.hasOwn(request,'password')))throw Error('Valore non valido per questa azione.');
  return request;
}
async function searchHistory(request){
  if(!api.history?.search)throw Error('Questo browser non espone la cronologia alle estensioni.');
  const rows=await api.history.search({text:request.text||'',...(request.start_time!==undefined?{startTime:request.start_time}:{}),...(request.end_time!==undefined?{endTime:request.end_time}:{}),maxResults:request.max_results||100});
  const history=rows.map(item=>{let url='';try{const parsed=new URL(item.url||'');parsed.username='';parsed.password='';for(const key of [...parsed.searchParams.keys()])if(/token|secret|password|passcode|auth|session|otp|code|key/i.test(key))parsed.searchParams.delete(key);url=parsed.href;}catch{}return {title:String(item.title||'').slice(0,300),url,last_visit_time:item.lastVisitTime||null,visit_count:item.visitCount||0,typed_count:item.typedCount||0};});
  return {performed:true,reason:'Cronologia del profilo browser corrente consultata su richiesta.',count:history.length,history};
}
async function rememberTab(target,tabId){
  const data=await api.storage.session.get(tabsKey(target)),ids=Array.isArray(data[tabsKey(target)])?data[tabsKey(target)]:[];
  await api.storage.session.set({[tabsKey(target)]:[...ids.filter(id=>id!==tabId),tabId],[tabKey(target)]:tabId});
}
async function currentTab(target){
  const key=tabKey(target),data=await api.storage.session.get(key);let id=data[key];
  if(id!==undefined&&await api.tabs.get(id).catch(()=>null))return id;
  const list=await api.storage.session.get(tabsKey(target)),ids=Array.isArray(list[tabsKey(target)])?list[tabsKey(target)]:[];
  for(const candidate of ids.slice().reverse())if(await api.tabs.get(candidate).catch(()=>null)){await api.storage.session.set({[key]:candidate});return candidate;}
  return null;
}
function describeTab(tab){
  let url='';try{const parsed=new URL(tab.url||'');url=['http:','https:'].includes(parsed.protocol)?parsed.origin+parsed.pathname:parsed.protocol+' (pagina interna del browser)';}catch{}
  return {tab_id:tab.id,window_id:tab.windowId,index:tab.index,title:String(tab.title||'').slice(0,240),url,active:!!tab.active,pinned:!!tab.pinned,audible:!!tab.audible,status:tab.status||'unknown'};
}
async function webTab(request,sender,{active=true}={}){
  let tab;
  if(request.tab_id!==undefined)tab=await api.tabs.get(request.tab_id).catch(()=>null);
  else if(active){const [current]=await api.tabs.query({active:true,lastFocusedWindow:true});tab=current;}
  else return null;
  if(!tab)throw Error('Scheda non trovata. Aggiorna l’elenco delle schede e riprova.');
  return tab;
}
api.tabs.onCreated.addListener(tab=>{
  void (async()=>{const data=await api.storage.session.get(null);for(const target of Object.keys(PRIME_PROVIDER_TARGETS)){const ids=data[tabsKey(target)]||[],opening=data[openingKey(target)],isChild=tab.openerTabId!==undefined&&(data[tabKey(target)]===tab.openerTabId||ids.includes(tab.openerTabId)),openedByVanessa=opening&&Date.now()-opening.createdAt<6000&&(tab.openerTabId===undefined||tab.openerTabId===opening.parentTabId);if(isChild||openedByVanessa){await rememberTab(target,tab.id);break;}}})();
});
api.tabs.onUpdated.addListener((tabId,changeInfo)=>{
  if(!changeInfo.url)return;
  void (async()=>{const data=await api.storage.session.get(null);for(const target of Object.keys(PRIME_PROVIDER_TARGETS)){const ids=data[tabsKey(target)]||[];if(ids.includes(tabId)&&PRIME_PROVIDER_TARGETS[target].origins.some(pattern=>{try{return new URL(pattern.replace('/*','/')).origin===new URL(changeInfo.url).origin;}catch{return false;}})){await api.storage.session.set({[tabKey(target)]:tabId});break;}}})();
});
async function sendResult(p,result){try{await api.tabs.sendMessage(p.primeTabId,{type:'prime-result',id:p.id,result});}catch{}}
async function originPermission(p){const origins=p.target==='web'?(p.permissionOrigins||[p.permissionOrigin].filter(Boolean)):PRIME_PROVIDER_TARGETS[p.target].origins;return origins.length>0&&api.permissions.contains({origins});}
async function pageOrigins(tabId){const rows=await api.scripting.executeScript({target:{tabId},func:()=>{const origins=new Set([location.origin]);for(const frame of document.querySelectorAll('iframe'))try{const url=new URL(frame.src||location.href,location.href);if(['http:','https:'].includes(url.protocol))origins.add(url.origin);}catch{}return [...origins].filter(origin=>/^https?:/.test(origin)).map(origin=>origin+'/*');}});return rows?.[0]?.result||[];}
async function createApproval(p){
  await api.storage.session.set({[storageKey(p.id)]:p});
  const tab=await api.tabs.create({url:api.runtime.getURL('approval.html')+'?id='+encodeURIComponent(p.id),active:true});
  await api.storage.session.set({[storageKey(p.id)]:{...p,approvalTabId:tab.id}});
}
async function runPageAction(p,value='',{dryRun=false,purchaseApproved=false,manualValueApproved=false}={}){
  let originInfo,origin,allowed=false;const deadline=Date.now()+15000;
  do{originInfo=await api.tabs.get(p.providerTabId).catch(()=>null);try{origin=new URL(originInfo?.url||'').origin;}catch{origin='';}allowed=p.target==='web'?['http:','https:'].includes(new URL(originInfo?.url||'about:blank').protocol):PRIME_PROVIDER_TARGETS[p.target].origins.some(pattern=>new URL(pattern.replace('/*','/')).origin===origin);if(allowed)break;if(!originInfo||Date.now()>=deadline)break;await new Promise(resolve=>setTimeout(resolve,250));}while(Date.now()<deadline);
  if(!originInfo)throw Error('La scheda provider non è disponibile. Riapri il sito ufficiale.');
  if(!allowed)throw Error('La scheda è fuori dai domini ufficiali autorizzati per questo servizio.');
  if(!dryRun&&['click','submit_form'].includes(p.request.action)){const marker={createdAt:Date.now(),parentTabId:p.providerTabId};await api.storage.session.set({[openingKey(p.target)]:marker});setTimeout(async()=>{const data=await api.storage.session.get(openingKey(p.target));if(data[openingKey(p.target)]?.createdAt===marker.createdAt)await api.storage.session.remove(openingKey(p.target));},7000);}
  const args=[p.request.action,p.request.element_label||p.request.field_label||'',value,purchaseApproved,dryRun,manualValueApproved,p.request.direction??'down',p.request.amount??700];
  const frameTarget=Number.isInteger(p.request.frame_id)?{frameIds:[p.request.frame_id]}:['inspect','read_page_text'].includes(p.request.action)?{allFrames:true}:{};
  let result;try{result=await api.scripting.executeScript({target:{tabId:p.providerTabId,...frameTarget},func:pageAction,args});}catch(error){if(['inspect','read_page_text'].includes(p.request.action)&&frameTarget.allFrames)result=await api.scripting.executeScript({target:{tabId:p.providerTabId},func:pageAction,args});else if(p.request.action==='fill_field')throw Error('Il browser non ha compilato il campo. Il valore non è stato conservato.');else throw error;}
  if(p.request.action==='read_page_text'){
    const frames=result.filter(x=>x.result?.performed).map(x=>({...x.result,frame_id:x.frameId}));
    const text=frames.map(frame=>frame.text).filter(Boolean).join('\n\n'),max=18000;
    if(!text)return failure('La pagina non ha restituito testo leggibile. Potrebbe essere ancora in caricamento o mostrare contenuti grafici.');
    return {performed:true,pageTitle:frames[0]?.pageTitle||'',pageUrl:frames[0]?.pageUrl||'',text:text.slice(0,max),truncated:text.length>max||frames.some(x=>x.truncated),frames:frames.map(x=>({frame_id:x.frame_id,pageUrl:x.pageUrl,characters:x.characters}))};
  }
  if(p.request.action==='inspect'){
    const frames=result.map(x=>x.result?.performed?{...x.result,frameId:x.frameId}:null).filter(Boolean);
    if(!frames.length)return failure('Non riesco a leggere i controlli in questa scheda.');
    const controls=frames.flatMap((frame,frameIndex)=>frame.controls.map(control=>({...control,frame:frame.frameTitle||frame.pageTitle||'Frame '+(frameIndex+1),frameUrl:frame.pageUrl,frame_id:frame.frameId,frame_origin:new URL(frame.pageUrl).origin})));
    const fields=frames.flatMap((frame,frameIndex)=>frame.fields.map(field=>({...field,frame:frame.frameTitle||frame.pageTitle||'Frame '+(frameIndex+1),frameUrl:frame.pageUrl,frame_id:frame.frameId,frame_origin:new URL(frame.pageUrl).origin})));
    const media=frames.flatMap((frame,frameIndex)=>frame.media.map(item=>({...item,frame:frame.frameTitle||frame.pageTitle||'Frame '+(frameIndex+1),frameUrl:frame.pageUrl})));
    return {performed:true,pageTitle:frames[0].pageTitle,pageUrl:frames[0].pageUrl,frames:frames.map(frame=>({title:frame.frameTitle,url:frame.pageUrl,controls:frame.controls.length,fields:frame.fields.length})),controls,fields,media,counts:{frames:frames.length,controls:controls.length,fields:fields.length,media:media.length}};
  }
  return result?.[0]?.result||failure('Il browser non ha restituito un esito.');
}
function pageAction(action,label,value,purchaseApproved,dryRun,manualValueApproved,direction,amount){
  const purchasePattern=/\b(buy|purchase|checkout|place order|confirm order|complete purchase|subscribe|abbonati|sottoscrivi|acquist[oaie]|compra|effettua l’ordine|effettua l'ordine|conferma ordine|concludi acquisto|upgrade plan|attiva piano)\b/i;
  const visible=el=>!!(el&&el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none');
  const tidy=value=>String(value||'').replace(/\s+/g,' ').trim();
  const accessible=el=>{const root=el.getRootNode(),labelledBy=(el.getAttribute('aria-labelledby')||'').split(/\s+/).filter(Boolean).map(id=>(root.getElementById?.(id)||document.getElementById(id))?.innerText||'').filter(Boolean).join(' ');return tidy(el.getAttribute('aria-label')||labelledBy||el.getAttribute('title')||el.getAttribute('data-tooltip-text')||el.getAttribute('data-tooltip-content')||el.getAttribute('data-title')||el.labels?.[0]?.innerText||el.innerText||el.textContent||el.value);};
  const labelled=el=>{const ids=(el.getAttribute('aria-labelledby')||'').split(/\s+/).filter(Boolean);return tidy(ids.map(id=>document.getElementById(id)?.innerText||'').filter(Boolean).join(' ')||el.labels?.[0]?.innerText||el.getAttribute('aria-label')||el.getAttribute('title')||el.getAttribute('data-tooltip-text')||el.getAttribute('data-tooltip-content')||el.placeholder||el.name||el.id);};
  const controlSelector='button,[role="button"],[role="menuitem"],[role="menuitemcheckbox"],[role="menuitemradio"],[role="tab"],[role="option"],[role="checkbox"],[role="radio"],[role="switch"],[role="slider"],[role="combobox"],[role="link"],[role="treeitem"],[role="gridcell"],a[href],input[type="button"],input[type="submit"],input[type="reset"],input[type="image"],input[type="checkbox"],input[type="radio"],summary,[tabindex]:not([tabindex="-1"]),[onclick]';
  const roots=[document];for(let i=0;i<roots.length;i++)for(const el of roots[i].querySelectorAll('*'))if(el.shadowRoot)roots.push(el.shadowRoot);
  const all=selector=>roots.flatMap(root=>[...root.querySelectorAll(selector)]);
  if(action==='read_page_text'){const text=roots.map(root=>root===document?String(document.body?.innerText||''):[...root.children].filter(visible).map(el=>el.innerText||'').join('\n')).join('\n').replace(/\u0000/g,'').trim();const max=18000;return {performed:true,pageTitle:document.title.slice(0,160),pageUrl:location.href.slice(0,500),text:text.slice(0,max),truncated:text.length>max,characters:text.length};}
  if(action==='inspect'){
    const controls=all(controlSelector).filter(visible).map((el,index)=>({index,label:accessible(el),role:el.getAttribute('role')||el.tagName.toLowerCase(),title:tidy(el.getAttribute('title')||el.getAttribute('data-tooltip-text')||el.getAttribute('data-tooltip-content')),disabled:!!el.disabled,expanded:el.getAttribute('aria-expanded'),hasPopup:el.getAttribute('aria-haspopup'),shortcut:el.getAttribute('aria-keyshortcuts')})).filter(x=>x.label||x.title);
    const fields=all('input:not([type="hidden"]),textarea,select,[contenteditable="true"],[role="textbox"]').filter(visible).map(el=>({label:labelled(el),type:el.type||el.tagName.toLowerCase(),disabled:!!el.disabled,options:el.tagName==='SELECT'?[...el.options].map(option=>option.textContent.trim()):undefined})).filter(x=>x.label);
    const media=all('video,audio').map((el,index)=>({index,kind:el.tagName.toLowerCase(),paused:el.paused,muted:el.muted,currentTime:Math.floor(el.currentTime),duration:Number.isFinite(el.duration)?Math.floor(el.duration):null}));
    return {performed:true,controls,fields,media,pageTitle:document.title.slice(0,120),frameTitle:document.title.slice(0,120),pageUrl:location.href.slice(0,500),counts:{controls:controls.length,fields:fields.length,media:media.length}};
  }
  if(action==='scroll_page'){
    const distance=Math.max(100,Math.min(3000,Number.isInteger(amount)?amount:700));
    if(direction==='top')window.scrollTo({top:0,behavior:'smooth'});
    else if(direction==='bottom')window.scrollTo({top:document.documentElement.scrollHeight,behavior:'smooth'});
    else window.scrollBy({top:(direction==='up'?-1:1)*distance,behavior:'smooth'});
    return {performed:true,reason:'Pagina scorsa '+direction+'.',scrollY:window.scrollY};
  }
  const wanted=String(label||'').trim().toLocaleLowerCase();
  if(action==='click'||action==='submit_form'){
    const matches=all(controlSelector).filter(visible).filter(el=>accessible(el).toLocaleLowerCase()===wanted);
    if(matches.length!==1)return {performed:false,reason:matches.length?'Etichetta ambigua: nessuna azione eseguita.':'Pulsante visibile non trovato.'};
    const el=matches[0];if(action==='submit_form'&&el.tagName==='A')return {performed:false,reason:'La destinazione è un collegamento, non un pulsante di invio.'};
    const form=el.closest('form'),riskText=[accessible(el),el.title,el.getAttribute('aria-label'),el.getAttribute('data-testid'),el.getAttribute('name'),el.href,form?.action,form?.getAttribute('data-testid'),location.pathname,document.title].filter(Boolean).join(' ');
    if(purchasePattern.test(riskText)&&!purchaseApproved)return {performed:false,requiresPurchaseConfirmation:true,reason:'Conferma necessaria prima di completare un acquisto.'};
    if(dryRun)return {performed:false,ready:true};
    el.click();return {performed:true,action,label:accessible(el)};
  }
  if(action==='fill_field'){
    const fields=all('input:not([type="hidden"]),textarea,select,[contenteditable="true"],[role="textbox"]').filter(visible).filter(el=>labelled(el).toLocaleLowerCase()===wanted);
    if(fields.length!==1)return {performed:false,reason:fields.length?'Etichetta campo ambigua: nessun valore inserito.':'Campo visibile non trovato.'};
    const field=fields[0],fieldLabel=tidy(field.labels?.[0]?.innerText||field.getAttribute('aria-label')||field.placeholder||field.name),sensitive=field.type==='password'||/password|passcode|codice|token|secret|chiave|api key|otp|one.?time|2fa|verifica|security|credential/i.test(fieldLabel+' '+field.autocomplete);
    if(sensitive&&!manualValueApproved)return {performed:false,requiresManualValue:true,reason:'Inserisci il dato di accesso nella finestra protetta dell’estensione.'};
    if(typeof value!=='string'||!value)return {performed:false,requiresManualValue:true,reason:'Inserisci il valore del campo nella finestra protetta dell’estensione.'};
    if(dryRun)return {performed:false,ready:true};
    if(field.tagName==='SELECT'){
      const options=[...field.options].filter(option=>option.value===value||tidy(option.textContent).toLocaleLowerCase()===value.toLocaleLowerCase());
      if(options.length!==1)return {performed:false,reason:'Opzione non trovata o ambigua.'};
      field.value=options[0].value;field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));return {performed:true,field:fieldLabel};
    }
    if(field.isContentEditable){field.textContent=value;field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));return {performed:true,field:fieldLabel};}
    const setter=Object.getOwnPropertyDescriptor(field instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value')?.set;if(!setter)return {performed:false,reason:'Campo non supportato.'};
    setter.call(field,value);field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));return {performed:true,field:fieldLabel};
  }
  return {performed:false,reason:'Azione sconosciuta.'};
}
async function pageMediaAction(action){
  const roots=[document];for(let i=0;i<roots.length;i++)for(const el of roots[i].querySelectorAll('*'))if(el.shadowRoot)roots.push(el.shadowRoot);
  const media=roots.flatMap(root=>[...root.querySelectorAll('video,audio')]);
  const outcomes=await Promise.all(media.map(async item=>{
    try{if(action==='stop_video')item.pause();else await item.play();return {performed:action==='stop_video'?item.paused:!item.paused};}
    catch(error){return {performed:false,reason:error.message||'Il browser ha bloccato la riproduzione.'};}
  }));
  const count=outcomes.filter(item=>item.performed).length;
  return {performed:count>0,videos:count,found:media.length,errors:outcomes.filter(item=>!item.performed).map(item=>item.reason||'Il player non ha cambiato stato.')};
}
async function runMediaAction(p){
  let results;
  try{results=await api.scripting.executeScript({target:{tabId:p.providerTabId,allFrames:true},func:pageMediaAction,args:[p.request.action]});}
  catch(error){results=await api.scripting.executeScript({target:{tabId:p.providerTabId},func:pageMediaAction,args:[p.request.action]});}
  const frames=results.map(item=>item.result).filter(Boolean),count=frames.reduce((sum,item)=>sum+(item.videos||0),0),errors=frames.flatMap(item=>item.errors||[]);
  return {performed:count>0,reason:count?(p.request.action==='stop_video'?'Player messi in pausa.':'Riproduzione avviata.'):(errors[0]||'Nessun player trovato nella scheda selezionata.'),videos:count,errors};
}
async function start(request,sender,id,origin){
  try{
    if(!sender.url||!primeOrigins.has(new URL(sender.url).origin)||!sender.tab?.id||!primeOrigins.has(origin))throw Error('Richiesta non proveniente dal workspace PRIME consentito.');
    if(request?.action==='revoke_task'){
      await api.storage.session.remove(taskKey(sender.tab.id));
      const entries=await api.storage.session.get(null);
      for(const [key,p] of Object.entries(entries))if(key.startsWith('prime-request:')&&p?.primeTabId===sender.tab.id){await api.storage.session.remove(key);await sendResult(p,failure('Autorizzazione revocata con STOP.'));if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});}
      return {performed:true,reason:'Autorizzazione del compito revocata.'};
    }
    validate(request);
    if(request.target==='web'&&request.action==='search_history'){
      if(!await api.permissions.contains({permissions:['history']}))throw Error('Il permesso cronologia è richiesto durante l’installazione o l’aggiornamento. Ricarica o aggiorna l’estensione e accetta il permesso richiesto dal browser.');
      return await searchHistory(request);
    }
    if(request.target==='web'&&request.action==='list_tabs'){
      const tabs=await api.tabs.query({});
      return {performed:true,reason:'Elenco aggiornato: '+tabs.length+' schede aperte in tutte le finestre del browser.',tabs:tabs.sort((a,b)=>a.windowId-b.windowId||a.index-b.index).map(describeTab)};
    }
    if(request.target==='web'&&['switch_tab','close_tab','open_tab','navigate_tab','go_back','go_forward','reload_tab','zoom_tab','duplicate_tab','pin_tab','unpin_tab','mute_tab','unmute_tab','fullscreen_window','restore_window'].includes(request.action)){
      if(request.action==='open_tab'){
        const window=await api.windows.getLastFocused();
        const tab=await api.tabs.create({url:request.url,active:true,windowId:window.id});
        return {performed:true,reason:'Nuova scheda aperta.',tab:describeTab(tab)};
      }
      const tab=await webTab(request,sender);
      if(request.action==='fullscreen_window'||request.action==='restore_window'){const win=await api.windows.get(tab.windowId);if(request.action==='fullscreen_window'){if(win.state!=='fullscreen')await api.storage.session.set({['prime-window-state:'+win.id]:win.state||'normal'});await api.windows.update(win.id,{state:'fullscreen'});return {performed:true,reason:'Finestra del browser a schermo intero.',window_id:win.id};}const saved=await api.storage.session.get('prime-window-state:'+win.id),state=saved['prime-window-state:'+win.id]||'normal';await api.windows.update(win.id,{state});await api.storage.session.remove('prime-window-state:'+win.id);return {performed:true,reason:'Finestra del browser ripristinata.',window_id:win.id,state};}
      if(request.action==='switch_tab'){
        const selected=await api.tabs.update(tab.id,{active:true});
        await api.windows.update(tab.windowId,{focused:true});
        return {performed:true,reason:'Scheda attivata.',tab:describeTab(selected)};
      }
      if(request.action==='close_tab'){
        await api.tabs.remove(tab.id);
        return {performed:true,reason:'Scheda chiusa.',tab_id:tab.id,title:tab.title||''};
      }
      if(request.action==='navigate_tab'){
        const changed=await api.tabs.update(tab.id,{url:request.url});
        return {performed:true,reason:'Indirizzo aperto nella scheda selezionata.',tab:describeTab(changed)};
      }
      if(request.action==='go_back'||request.action==='go_forward'){
        const method=request.action==='go_back'?'goBack':'goForward';
        if(typeof api.tabs[method]!=='function')throw Error('Comando di cronologia non supportato da questo browser.');
        await api.tabs[method](tab.id);
        return {performed:true,reason:request.action==='go_back'?'Pagina precedente aperta.':'Pagina successiva aperta.',tab_id:tab.id};
      }
      if(request.action==='reload_tab'){
        await api.tabs.reload(tab.id);
        return {performed:true,reason:'Scheda aggiornata.',tab_id:tab.id};
      }
      if(request.action==='zoom_tab'){
        await api.tabs.setZoom(tab.id,request.zoom_percent/100);
        return {performed:true,reason:'Zoom impostato al '+request.zoom_percent+'%.',tab_id:tab.id};
      }
      if(request.action==='duplicate_tab'){
        const duplicate=await api.tabs.duplicate(tab.id);
        return {performed:true,reason:'Scheda duplicata.',tab:describeTab(duplicate)};
      }
      if(request.action==='pin_tab'||request.action==='unpin_tab'||request.action==='mute_tab'||request.action==='unmute_tab'){
        const properties=request.action==='pin_tab'?{pinned:true}:request.action==='unpin_tab'?{pinned:false}:request.action==='mute_tab'?{muted:true}:{muted:false};
        const changed=await api.tabs.update(tab.id,properties);
        return {performed:true,reason:request.action==='pin_tab'?'Scheda fissata.':request.action==='unpin_tab'?'Scheda rimossa dalle schede fissate.':request.action==='mute_tab'?'Audio della scheda disattivato.':'Audio della scheda riattivato.',tab:describeTab(changed)};
      }
    }
    const normalizedInstructions=request.task_instructions.trim();    const p={id,request:{...request,task_instructions:normalizedInstructions},origin,target:request.target,primeTabId:sender.tab.id,createdAt:Date.now()};
    if(['stop_video','play_video'].includes(request.action)){
      const tab=await webTab(request,sender);
      if(!/^https?:/.test(tab.url||''))throw Error('La scheda richiesta non supporta i comandi del player.');
      p.providerTabId=tab.id;p.permissionOrigins=await pageOrigins(tab.id);
      const missing=[];for(const permission of p.permissionOrigins)if(!(await api.permissions.contains({origins:[permission]})))missing.push(permission);
      if(missing.length){p.permissionOrigins=missing;await createApproval(p);return {pending:true,reason:'Concedi una volta l’accesso ai siti della scheda per controllare il player.'};}
      return {...await runMediaAction(p),tab_id:tab.id,title:tab.title||''};
    }
    if(request.action==='open_service'){
      const tab=await api.tabs.create({url:request.target==='web'?request.url:PRIME_PROVIDER_TARGETS[request.target].url,active:true});await rememberTab(request.target,tab.id);
      return {performed:true,reason:'Nuova scheda del servizio ufficiale aperta.',provider:request.target};
    }
    if(request.action==='open_page'){
      const tab=await api.tabs.create({url:request.url,active:true});return {performed:true,reason:'Guida PRIME aperta in una nuova scheda.',tabId:tab.id};
    }
    const providerTabId=request.target==='web'?(await webTab(request,sender)).id:await currentTab(request.target);if(!providerTabId)throw Error('Apri prima il sito ufficiale richiesto.');
    if(request.target==='web'&&['click','fill_field','submit_form'].includes(request.action)){const selected=await api.tabs.get(providerTabId);await api.tabs.update(providerTabId,{active:true});await api.windows.update(selected.windowId,{focused:true});}
    p.providerTabId=providerTabId;if(request.target==='web'){const activeTab=await api.tabs.get(providerTabId);let page;try{page=new URL(activeTab.url);}catch{}if(!page||!['http:','https:'].includes(page.protocol))throw Error('La scheda attiva non è controllabile.');p.permissionOrigins=typeof request.frame_origin==='string'?[new URL(request.frame_origin).origin+'/*']:request.action==='inspect'?await pageOrigins(providerTabId):[page.origin+'/*'];if(typeof request.frame_origin==='string'){const requestedOrigin=new URL(request.frame_origin).origin;if(!p.permissionOrigins.some(item=>item.startsWith(requestedOrigin+'/')))throw Error('Il frame richiesto non appartiene a questa pagina.');p.permissionOrigins=[requestedOrigin+'/*'];}const missing=[];for(const permission of p.permissionOrigins)if(!(await api.permissions.contains({origins:[permission]})))missing.push(permission);if(missing.length){p.permissionOrigins=missing;await createApproval(p);return {pending:true,reason:'Concedi una volta l’accesso ai siti presenti in questa pagina.'};}}
    if(!(await originPermission(p))){await createApproval(p);return {pending:true,reason:'Concedi una volta l’accesso al sito richiesto.'};}
    const initialValue=typeof request.value==='string'?request.value:'';
    const preview=await runPageAction(p,initialValue,{dryRun:true});
    if(preview.requiresPurchaseConfirmation||preview.requiresManualValue){p.requiresPurchaseConfirmation=!!preview.requiresPurchaseConfirmation;p.requiresManualValue=!!preview.requiresManualValue;await createApproval(p);return {pending:true,reason:preview.reason};}
    const result=preview.ready?await runPageAction(p,initialValue):preview;
    await sendResult(p,result);return {pending:true};
  }catch(error){return failure(error.message||'Azione non eseguita.');}
}
api.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(message?.type==='prime-start'){
    start(message.request,sender,message.id,message.origin).then(sendResponse);return true;
  }
  if(message?.type==='prime-pending'&&sender.url?.startsWith(api.runtime.getURL(''))){
    api.storage.session.get(storageKey(message.id)).then(data=>sendResponse(data[storageKey(message.id)]||null));return true;
  }
  if(message?.type==='prime-cancel'&&sender.url?.startsWith(api.runtime.getURL(''))){
    api.storage.session.get(storageKey(message.id)).then(async data=>{const p=data[storageKey(message.id)];if(p){await api.storage.session.remove(storageKey(message.id));await sendResult(p,failure('Richiesta annullata con STOP.'));if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});}sendResponse({ok:true});});return true;
  }
  if(message?.type==='prime-run-approved'&&sender.url?.startsWith(api.runtime.getURL(''))){
    (async()=>{
      const data=await api.storage.session.get(storageKey(message.id)),p=data[storageKey(message.id)];if(!p)throw Error('Richiesta scaduta.');
      if(Date.now()-p.createdAt>15*60*1000)throw Error('Sessione scaduta.');
      if(['open_service','open_page'].includes(p.request.action)){
        const tab=p.request.action==='open_service'?await api.tabs.create({url:p.target==='web'?p.request.url:PRIME_PROVIDER_TARGETS[p.target].url,active:true}):await api.tabs.create({url:p.request.url,active:true});
        if(p.request.action==='open_service')await rememberTab(p.target,tab.id);
        await api.storage.session.remove(storageKey(p.id));await sendResult(p,{performed:true,reason:p.request.action==='open_service'?'Nuova scheda del servizio ufficiale aperta.':'Guida PRIME aperta in una nuova scheda.'});
        if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});
        sendResponse({ok:true,reason:'Compito avviato.'});return;
      }
      if(['stop_video','play_video'].includes(p.request.action)){
        const result=await runMediaAction(p);await api.storage.session.remove(storageKey(p.id));await sendResult(p,result);
        if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});
        sendResponse({ok:!!result.performed,reason:result.reason});return;
      }
      if(!(await originPermission(p)))throw Error('Accesso al solo sito non autorizzato.');
      const manualValue=typeof message.value==='string'?message.value:'';
      const manualValueApproved=!!p.requiresManualValue&&manualValue.length>0;
      const preview=await runPageAction(p,manualValueApproved?manualValue:(p.request.value||''),{dryRun:true,purchaseApproved:!!message.purchaseApproved,manualValueApproved});
      if(preview.requiresPurchaseConfirmation){p.requiresPurchaseConfirmation=true;await api.storage.session.set({[storageKey(p.id)]:p});sendResponse({ok:false,requiresPurchaseConfirmation:true,reason:preview.reason});return;}
      if(preview.requiresManualValue){p.requiresManualValue=true;await api.storage.session.set({[storageKey(p.id)]:p});sendResponse({ok:false,requiresManualValue:true,reason:preview.reason});return;}
      const value=manualValueApproved?manualValue:(p.request.value||'');
      const result=preview.ready?await runPageAction(p,value,{purchaseApproved:!!message.purchaseApproved,manualValueApproved}):preview;
      if(result.requiresPurchaseConfirmation||result.requiresManualValue){sendResponse({ok:false,...result});return;}
      await api.storage.session.remove(storageKey(p.id));await sendResult(p,result);
      if(p.approvalTabId)await api.tabs.remove(p.approvalTabId).catch(()=>{});
      sendResponse({ok:!!result.performed,reason:result.reason||result.action||result.field||''});
    })().catch(async error=>{const data=await api.storage.session.get(storageKey(message.id)),p=data[storageKey(message.id)];if(p){await api.storage.session.remove(storageKey(message.id));await sendResult(p,failure(error.message));}sendResponse({ok:false,reason:error.message});});return true;
  }
});


